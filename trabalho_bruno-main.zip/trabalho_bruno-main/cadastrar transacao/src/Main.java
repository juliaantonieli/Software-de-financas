public class Main {
    public static void main(String[] args) {
        Financeiro financeiro = new Financeiro();
        new Interface(financeiro);
    }
}
